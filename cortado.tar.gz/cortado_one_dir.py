#!/usr/bin/env python
# -*- coding: utf-8 -*-

from cortado_reorient import main


if __name__ == '__main__':
    main()
