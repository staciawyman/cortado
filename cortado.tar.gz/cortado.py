#!/usr/bin/env python
# -*- coding: utf-8 -*-

from cortadoCORE import main


if __name__ == '__main__':
    main()
