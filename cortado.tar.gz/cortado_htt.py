#!/usr/bin/env python
# -*- coding: utf-8 -*-

from cortado_htt_code import main


if __name__ == '__main__':
    main()
